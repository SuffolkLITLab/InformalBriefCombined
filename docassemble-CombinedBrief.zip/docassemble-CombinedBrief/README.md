# docassemble.CombinedBrief

A docassemble extension.

## Author

Jack Brandt, john.brandt@su.suffolk.edu

